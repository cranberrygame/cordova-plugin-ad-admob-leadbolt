//
//  ViewController.m
//  SampleAppiOSAFWAdMobDFP
//
//  Created by Jay on 12/02/2015.
//  Copyright (c) 2015 LB. All rights reserved.
//

@import GoogleMobileAds;

#import "ViewController.h"
#import "AppTracker.h"

#define kSampleAdUnitID_AFW    @"ca-app-pub-8211302556993806/4037500371"

@interface ViewController () <GADInterstitialDelegate>

@property(nonatomic, strong) GADInterstitial *interstitial;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //disable show button till ad is availble
    self.show.enabled = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Button Events
-(IBAction)loadAd:(id)sender
{
    // initialize AdMob Interstitial
    self.interstitial = [[DFPInterstitial alloc] init];
    self.interstitial.adUnitID = kSampleAdUnitID_AFW;
    self.interstitial.delegate = self;
    [self.interstitial loadRequest:[DFPRequest request]];
}

-(IBAction)showAd:(id)sender
{
    [self.interstitial presentFromRootViewController:self];
}


#pragma mark AdMob Events
-(void)interstitialDidReceiveAd:(GADInterstitial *)ad {
    self.show.enabled = YES;
}

-(void)interstitialWillPresentScreen:(GADInterstitial *)ad {
    // disable show button once the Ad is displayed on screen
    self.show.enabled = NO;
}

@end
