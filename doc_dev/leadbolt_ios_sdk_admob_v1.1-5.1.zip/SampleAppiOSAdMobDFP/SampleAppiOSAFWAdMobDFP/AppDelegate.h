//
//  AppDelegate.h
//  SampleAppiOSAFWAdMobDFP
//
//  Created by Jay on 12/02/2015.
//  Copyright (c) 2015 LB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

