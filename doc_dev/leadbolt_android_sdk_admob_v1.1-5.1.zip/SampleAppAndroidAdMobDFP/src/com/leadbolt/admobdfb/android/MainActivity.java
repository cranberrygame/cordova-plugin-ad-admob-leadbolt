package com.leadbolt.admobdfb.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class MainActivity extends Activity {
	
	private InterstitialAd imageInterstitial;
	private Button buttonLoad;
	private Button buttonShow;
	
	private final String APP_AD_UNIT_ID = "ca-app-pub-8211302556993806/1084033972"; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// Create an interstitial.
		imageInterstitial = new InterstitialAd(this);
		imageInterstitial.setAdUnitId(APP_AD_UNIT_ID);
		imageInterstitial.setAdListener(new AdListener() {
			@Override
			public void onAdClosed() {
				showToast("onAdClosed");
			}
			@Override
			public void onAdFailedToLoad(int errorCode) {
				showToast("onAdFailedToLoad - "+errorCode);
			}
			@Override
			public void onAdLeftApplication() {
				showToast("onAdLeftApplication");
			}
			@Override
			public void onAdOpened() {
				showToast("onAdOpened");
				buttonShow.setEnabled(false);
			}
			@Override
			public void onAdLoaded() {
				showToast("onAdLoaded");
				buttonShow.setEnabled(true);
			}
		});
		
	    
		buttonLoad = (Button)findViewById(R.id.button_load);
		buttonLoad.setOnClickListener(new OnClickListener() {			
			@Override
			public void onClick(View v) {
				loadAd(imageInterstitial);
			}
		});

		buttonShow = (Button)findViewById(R.id.button_show);
		buttonShow.setEnabled(false);
		buttonShow.setOnClickListener(new OnClickListener() {			
			@Override
			public void onClick(View v) {
				showAd(imageInterstitial);
			}
		});
	}
	
	private void loadAd(InterstitialAd interstitial) {
	    // Create ad request.
	    AdRequest adRequest = new AdRequest.Builder().build();

	    // Begin loading your interstitial.
	    interstitial.loadAd(adRequest);				
	}
	
	private void showAd(InterstitialAd interstitial) {
		interstitial.show();
	}
	
	private void showToast(String msg) {
		Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
	}
}
